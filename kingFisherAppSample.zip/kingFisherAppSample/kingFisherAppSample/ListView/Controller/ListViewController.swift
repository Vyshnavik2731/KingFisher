//
//  ListViewController.swift
//  kingFisherAppSample
//
//  Created by Vyshnavi on 4/11/24.
//

import UIKit
import Kingfisher
import XCGLogger
import FTLinearActivityIndicator


class ListViewController: UIViewController {
    
    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet weak var standAloneIndicatorView: FTLinearActivityIndicator!
    @IBOutlet weak var networkErrorImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var listTableView: UITableView!
    var listData: ListModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        standAloneIndicatorView.startAnimating()
        XCGLogger.info("Article List controller loaded")
        setUpListVC()
        if NetworkManager.isReachable {
            titleLabel.isHidden = false
            listTableView.isHidden = false
            searchButton.isHidden = false
        } else {
            titleLabel.isHidden = true
            listTableView.isHidden = true
            searchButton.isHidden = true
            standAloneIndicatorView.stopAnimating()
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        fetchDataList()
        CommonUtility.shared.checkForNetworkreachability(imageView: networkErrorImageView)
    }
    
    func setUpListVC(){
        titleLabel.text = "Articles".localized
        titleLabel.font = AppFont.robotoBlack.of(size: 30)
        listTableView.delegate = self
        listTableView.dataSource = self
        listTableView.register(UINib(nibName: "ListTableViewCell", bundle: nil), forCellReuseIdentifier: "ListTableViewCell")
    }
    
    @IBAction func searchAction(_ sender: Any) {
        
    }
    
    func fetchDataList() {
        let apiManager = APIClient()
        apiManager.fetchAPIData { result in
            self.listData = result
            self.listTableView.reloadData()
            if self.standAloneIndicatorView.isAnimating{
                self.standAloneIndicatorView.stopAnimating()
            }
        }
    }
    
}

extension ListViewController: UITableViewDelegate,UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return listData?.articles?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell: ListTableViewCell = tableView.dequeueReusableCell(withIdentifier: "ListTableViewCell", for: indexPath) as? ListTableViewCell {
            if let imageURLString = listData?.articles?[indexPath.row].urlToImage, let urlPhotos = URL(string: imageURLString) {
                cell.contentImage.kf.setImage(with: urlPhotos)
            }
            cell.addShadow()
            cell.title.text = listData?.articles?[indexPath.row].title
            cell.descriptionLabel.text = listData?.articles?[indexPath.row].description
            if let date = listData?.articles?[indexPath.row].publishedAt{
                cell.publishedDate.text = CommonUtility.shared.getDateFromString(dateString: date)
            }
            return cell
        }
        return UITableViewCell()
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let footer = UIView()
        footer.backgroundColor = .white
        return footer
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 20.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "List", bundle:nil)
        if let detailVC = storyBoard.instantiateViewController(withIdentifier: "DetailViewController") as?
            DetailViewController {
            detailVC.modalPresentationStyle = .fullScreen
            let articleData = listData?.articles?[safe: indexPath.row]
            detailVC.articleTitle = articleData?.title ?? ""
            detailVC.content = articleData?.content ?? ""
            if let date = articleData?.publishedAt{
                detailVC.publishedSlotDetails = updateTimeInDetailScreen(date: date)
            }
            detailVC.imageURL = articleData?.urlToImage ?? ""
            self.present(detailVC, animated: true)
        }
    }
    
    func updateTimeInDetailScreen (date: String) -> String {
        var dateString = ""
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:SSZ"
        dateFormatter.timeZone = TimeZone.current
        if let dateStr = dateFormatter.date(from: date),let diff = Calendar.current.dateComponents([.hour], from: dateStr, to: Date()).hour, diff > 24 {
            let calendar = Calendar.current
            let components = calendar.dateComponents([.month,.year,.day], from: dateStr)
            let monthStr = Calendar.current.shortMonthSymbols[(components.month ?? 0) - 1]
            dateString = "\(monthStr) \(components.day ?? 0), \(components.year ?? 0)"
        } else {
            if let dateStr = dateFormatter.date(from: date),let diff = Calendar.current.dateComponents([.hour], from: dateStr, to: Date()).hour, diff < 24 {
                dateString = "\(diff.description) hrs ago"
            }
        }
        return dateString
    }
}
    

