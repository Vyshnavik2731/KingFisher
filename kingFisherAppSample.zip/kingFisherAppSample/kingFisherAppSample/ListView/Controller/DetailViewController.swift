//
//  DetailViewController.swift
//  kingFisherAppSample
//
//  Created by Vyshnavi on 4/11/24.
//

import UIKit
import Kingfisher
import XCGLogger
import Loaf

class DetailViewController: UIViewController {
    
    var articleTitle = ""
    var publishedSlotDetails = ""
    var imageURL = ""
    var content = ""

    @IBOutlet weak var favoriteButton: UIButton!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var publishedTime: UILabel!
    @IBOutlet weak var articleImage: UIImageView!
    @IBOutlet weak var contentView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        XCGLogger.info("Detail List controller loaded")
        titleLabel.text = articleTitle
        publishedTime.text = publishedSlotDetails
        articleImage.kf.setImage(with: URL(string: imageURL))
        contentView.text = content
    }
    
    
    @IBAction func favoriteAction(_ sender: Any) {
        favoriteButton.imageView?.image = UIImage(contentsOfFile: "favorites_Selected")
        Loaf("Item is added to favorites", sender: self).show()
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.dismiss(animated: false)
    }
    
}
