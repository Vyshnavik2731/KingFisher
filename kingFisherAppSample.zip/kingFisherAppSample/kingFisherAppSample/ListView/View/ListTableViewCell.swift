//
//  ListTableViewCell.swift
//  
//
//  Created by Vyshnavi on 4/11/24.
//

import UIKit

class ListTableViewCell: UITableViewCell {

    @IBOutlet weak var publishedDate: UILabel!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var contentImage: UIImageView!
   
    override func awakeFromNib() {
        super.awakeFromNib()
        setUpCell()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
            super.setSelected(selected, animated: animated)
    }
    
    func setUpCell(){
        publishedDate.font = AppFont.robotoThin.of(size: 11.0)
        title.font = AppFont.robotoRegular.of(size: 15.0)
        descriptionLabel.font = AppFont.robotoRegular.of(size: 8.0)
        contentImage.clipsToBounds = true
        contentImage.layer.cornerRadius = 12.0
        removeCellSelectionColour()
    }
    
    func addShadow () {
        contentView.layer.cornerRadius = 12
        contentView.layer.masksToBounds = true;
        
        layer.shadowColor = UIColor.black.withAlphaComponent(0.2).cgColor
        layer.shadowOffset = CGSize(width:0,height: 0)
        layer.shadowRadius = 2.5
        layer.shadowOpacity = 0.3
        layer.masksToBounds = false;
        layer.shadowPath = UIBezierPath(roundedRect:self.bounds, cornerRadius: contentView.layer.cornerRadius).cgPath
        layer.shouldRasterize = true
        layer.rasterizationScale = UIScreen.main.scale
        
    }
    
}

extension UITableViewCell{

    func removeCellSelectionColour(){
        let clearView = UIView()
        clearView.backgroundColor = UIColor.clear
        UITableViewCell.appearance().selectedBackgroundView = clearView
    }

}
