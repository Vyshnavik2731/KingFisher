//
//  APIClient.swift
//  kingFisherAppSample
//
//  Created by Vyshnavi on 4/11/24.
//

import Foundation
import UIKit
import Alamofire
import XCGLogger


class APIClient {
    static let sharedInstance = APIClient()
    
    func fetchAPIData ( onCompletion handler:@escaping ((_ result: ListModel?) -> Void)){
        let url = "https://mocki.io/v1/e91eafa6-46f7-4bd1-87f7-2770c7b7e194";
        if NetworkManager.isReachable {
            AF.request(url, method: .get, parameters: nil, encoding: URLEncoding.default, headers: nil, interceptor: nil)
                .response{ [self] resp in
                    switch resp.result{
                    case .success(let data):
                        do{
                            let jsonData = try JSONDecoder().decode(ListModel.self, from: data!)
                            let data = self.prepareRequestBody(body: jsonData)
                            CacheManager.shared.cacheDataToLocal(with: data) // stores data in cache
                            XCGLogger.info("Data parsed successfully")
                            handler(jsonData)
                        } catch {
                            XCGLogger.info("unable to parse error: \(error.localizedDescription)")
                            handler(nil)
                        }
                    case .failure(let error):
                        print(error.localizedDescription)
                    }
                }
        }
        
    }
    
    func prepareRequestBody<T:Codable>(body:T) -> [String:Any]? {
        let jsonEncoder = JSONEncoder()
        jsonEncoder.outputFormatting = .prettyPrinted
        guard let requestBody = try? jsonEncoder.encode(body)else {
            return nil
        }
        guard let params = try? JSONSerialization.jsonObject(with: requestBody, options: .mutableContainers) as? [String: Any] else {
            return nil
        }
        return params
    }
    
}

