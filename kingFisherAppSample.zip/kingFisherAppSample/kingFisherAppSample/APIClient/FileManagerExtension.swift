//
//  FileManagerExtension.swift
//  kingFisherAppSample
//
//  Created by Vyshnavi on 4/11/24.
//


import Foundation

extension FileManager {

    var documentDirectoryPath: String {
        if let documentDirectoryURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            return documentDirectoryURL.absoluteString
        }
        return ""
    }

    func getDocumentPath(forItemName name: String) -> String {
        documentDirectoryPath.stringByAppendingPathComponent(name)
    }

    func directoryExists(atPath filePath: String) -> Bool {
        var isDir = ObjCBool(true)
        return FileManager.default.fileExists(atPath: filePath, isDirectory: &isDir )
    }

    func createDirectory(withFolderName name: String) -> Bool {
        let finalPath = documentDirectoryPath.stringByAppendingPathComponent(name)
        do {
            try createDirectory(atPath: finalPath, withIntermediateDirectories: true, attributes: nil)
            return true
        } catch {
            return false
        }
    }
}

extension String {
    func stringByAppendingPathComponent(_ path: String) -> String {
        let fileUrl = URL(fileURLWithPath: self)
        let filePath = fileUrl.appendingPathComponent(path).path
        return filePath
    }
}

