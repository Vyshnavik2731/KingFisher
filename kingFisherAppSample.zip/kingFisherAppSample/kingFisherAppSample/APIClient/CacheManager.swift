//
//  CacheManager.swift
//  kingFisherAppSample
//
//  Created by Vyshnavi on 4/11/24.
//

import Foundation
import XCGLogger

final class CacheManager: NSObject {

    static let shared = CacheManager()
    var localServiceCacheDownloadDir: String {
        return "LocalData"
    }

    private func getBaseForCacheLocal(with fileName:String) -> String? {

        let filePath = FileManager.default.getDocumentPath(forItemName: localServiceCacheDownloadDir)
        if FileManager.default.directoryExists(atPath: filePath) {
            return filePath.stringByAppendingPathComponent(fileName)
        } else {
            if  FileManager.default.createDirectory(withFolderName: localServiceCacheDownloadDir) {
                return filePath.stringByAppendingPathComponent(fileName)
            }
        }
        return nil
    }

    @discardableResult
    func cacheDataToLocal<T>(with object: T) -> Bool {
        var archivedData: Data?
        if let file = getBaseForCacheLocal(with: "") {
            let  data = try! NSKeyedArchiver.archivedData(withRootObject: object, requiringSecureCoding: false)
            XCGLogger.info("Data stored to local cache successfully")
            archivedData = data
            return ((archivedData?.isEmpty) != nil)
        }
        return false
    }



    func removeAllCacheDirs() {
        if let file = getBaseForCacheLocal(with: "") {
            do {
                try FileManager.default.removeItem(atPath: file)
                XCGLogger.info("Data removed from local successfully")
            } catch {
                XCGLogger.info("error in remove dir \(error.localizedDescription)")
            }
        }
    }

    func removeCachedDataAt() {
        
        if let file = getBaseForCacheLocal(with: "LocalData") {
            do {
                try FileManager.default.removeItem(atPath: file)
            } catch {
                XCGLogger.info("error in remove dir \(error.localizedDescription)")
            }
        }
    }
}
