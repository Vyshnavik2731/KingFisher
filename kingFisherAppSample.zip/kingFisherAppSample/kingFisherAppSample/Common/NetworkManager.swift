//
//  NetworkManager.swift
//  kingFisherAppSample
//
//  Created by Vyshnavi on 4/11/24.
//

import Foundation
import Reachability

class NetworkManager: NSObject {
    // Private Properties
    static let sharedInstance = NetworkManager()
    private static var reachabilityStatus = Reachability.Connection.unavailable
    private let reachability = try! Reachability()

    // Public properties
    static var isReachable : Bool {
        self.reachabilityStatus != .unavailable
    }

    static var networkStatus : Reachability.Connection {
        self.reachabilityStatus
    }

    static var isReachableViaWifi : Bool {
        self.reachabilityStatus == .wifi
    }

    static var isReachableViaCullular : Bool {
        self.reachabilityStatus == .cellular
    }

    private func postNotification() {
        NotificationCenter .default.post(name: NSNotification.Name(rawValue: "networkStatusChanged"), object: nil)
    }

    // Starts monitoring the network availability status
    func startMonitoring() {
        NetworkManager.reachabilityStatus = NetworkManager.sharedInstance.reachability.connection
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(self.reachabilityChanged),
                                               name: Notification.Name.reachabilityChanged,
                                               object: reachability)
        do {
            try self.reachability.startNotifier()
        } catch {
            debugPrint("Could not start reachability notifier")
        }
    }

    // Stops monitoring the network availability status
    func stopMonitoring() {
        NetworkManager.sharedInstance.reachability.stopNotifier()
        NotificationCenter.default.removeObserver(self,
                                                  name: Notification.Name.reachabilityChanged,
                                                  object: reachability)
    }

    // Called when networl status changed
    @objc func reachabilityChanged(notification: Notification) {
        if let reachability = notification.object as? Reachability {
            NetworkManager.reachabilityStatus = reachability.connection
            switch reachability.connection {
            case .unavailable:
                debugPrint("Network became unreachable")
            case .wifi:
                debugPrint("Network reachable through WiFi")
            case .cellular:
                debugPrint("Network reachable through Cellular Data")
            }
            self.postNotification()
        }
    }

    func isNetworkReachable(completed: @escaping (NetworkManager) -> Void) { // To execute a closure once
        if NetworkManager.reachabilityStatus != .unavailable {
            completed(self)
        }
    }
    
    static func addObserver(observer: Any, selector: Selector) {
        NotificationCenter.default.addObserver(observer, selector: selector, name: NSNotification.Name("networkStatusChanged"), object: nil)
    }
}

