//
//  CommonUtility.swift
//  kingFisherAppSample
//
//  Created by Vyshnavi on 4/11/24.
//

import UIKit

class CommonUtility {
    static let shared = CommonUtility()
    
    func checkForNetworkreachability (imageView: UIImageView) {
        if NetworkManager.isReachable{
            imageView.isHidden = true
        } else {
            imageView.isHidden = false
            imageView.contentMode = .scaleToFill
            imageView.image = UIImage(named: "NoNetwork")
        }
    }
    
    func getDateFromString(dateString: String) -> String? {
        var dateStr = ""
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:SSZ"
        dateFormatter.timeZone = TimeZone.current
        let date = dateFormatter.date(from: dateString)
        let calendar = Calendar.current
        if let date = date {
            let components = calendar.dateComponents([.month,.year,.day], from: date)
            let monthStr = Calendar.current.shortMonthSymbols[(components.month ?? 0) - 1]
            dateStr = "\(monthStr) \(components.day ?? 0), \(components.year ?? 0)"
        }
        return dateStr
    }
    
}

enum AppFont: String {
    case robotoBlack = "Roboto-Black"
    case robotoBold = "Roboto-Bold"
    case robotoRegular = "Roboto-Regular"
    case robotoLight = "Roboto-Light"
    case robotoThin = "Roboto-Thin"
    func of(size: CGFloat) -> UIFont {
        guard let font = UIFont(appFont: self.rawValue, withSize: size) else {
            return UIFont.systemFont(ofSize:size.dpValue)
        }
        return font
    }
}

extension String{
    var localized: String { NSLocalizedString(self, comment: "") }
}

extension CGFloat {
    // Considering minimum size(i.e width = 320) and scaling to larger size
    var dpValue: CGFloat {
        guard self > 0 else { return self }
        return (self / 320) * UIScreen.main.bounds.width
    }
}

extension UIFont {
    // MARK: - Convenience init
    fileprivate convenience init?(appFont font: String, withSize size: CGFloat) {
        // Force unrapping since sure about the font existance
        self.init(name: font, size: size)
    }
}

extension Array {
    subscript(safe index: Index) -> Element? {
        let isValidIndex = index >= 0 && index < count
        return isValidIndex ? self[index] : nil
    }
}



